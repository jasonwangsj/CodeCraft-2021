#include <iostream>
#include <fstream>
#include <unordered_map>
#include<algorithm>
#include <string>
#include<vector>
#include<fstream>
#include <iostream>
#include<bits/stdc++.h>
#include <math.h>
#include <functional>
#include <iterator>
using namespace std;

struct Host{
	string HostName;
 	int cpu;
 	int mem;
 	int price;
 	int energy_cost;
 	float performance_cost;
};

struct VM{
 	string vmName;
 	int cpu;
 	int mem;
 	int node_flag;
};

struct HostState{
 	int hostID;
 	int cpu_A;
 	int mem_A;
	int cpu_B;
	int mem_B;
	int vm_num;
	int energy_cost;
	int flag;
};

struct VMState{
 	int vmID;
 	string vmName;
	int hostID;
 	int nodeFlag;
};

struct Request{
	string type;
	int vmID;
	string vmName;
};

struct Host_purchase{
	string HostName;
	int Hostnum;
};


vector<string> ReadInput(){
	ifstream in("training-1.txt");
	string filename;
	string line;
	vector<string>  input_data;

	if(in){
		while (getline(in, line)){
			input_data.push_back(line);
		}
	}

	else{
		cout << "no such file" << endl;
	}
	return input_data;
}


vector<string> ReadInput1(){
	string str;
	vector<string> input_data;
	while(getline(cin,str)){
		input_data.push_back(str);
	}
	return input_data;
}

vector<string> split(string s, char delim){
    vector<string> v;
    stringstream stringstream1(s);
    string tmp;
    while(getline(stringstream1, tmp, delim)){
        v.push_back(tmp);
    }
    return v;
}

bool compare(Host a, Host b){
	return a.performance_cost>b.performance_cost;
}

vector<Host> GetHosts(vector<string> input_data){
	vector<Host> Hosts;
	vector<string> input_split;
	int hostnum = atoi(input_data[0].c_str());

	for(int i=1;i<=hostnum;i++){
		input_split = split(input_data[i],',');
		Host host;
		host.HostName = input_split[0].substr(1);
		host.cpu = atoi(input_split[1].c_str());
		host.mem = atoi(input_split[2].c_str());
		host.price = atoi(input_split[3].c_str());
		host.energy_cost = atoi(input_split[4].c_str());
		host.performance_cost = host.cpu*host.mem*1.0/host.price;
		Hosts.push_back(host);
	}
	sort(Hosts.begin(), Hosts.end(), compare);
	return Hosts;
}

unordered_map<string, VM> GetVMs(vector<string> input_data){
		int hostnum = atoi(input_data[0].c_str());
	int vmnum = atoi(input_data[hostnum+1].c_str());
	vector<string> input_split;
	unordered_map<string, VM> VMs;
	for(int i=hostnum+2;i<=hostnum+2+vmnum-1;i++){
		input_split = split(input_data[i],',');
		VM vm;
		vm.vmName = input_split[0].substr(1);
		vm.cpu = atoi(input_split[1].c_str());
		vm.mem = atoi(input_split[2].c_str());
		vm.node_flag = atoi(input_split[3].c_str());
		VMs.insert(make_pair(vm.vmName, vm));
	}
	return VMs;
}

vector<Request> Request_process(vector<string> request_list, vector<VMState> VM_list){
	int i;
	vector<Request> Requests;
	vector<string> request_split;
	for(i=0;i<request_list.size();i++){
		request_split = split(request_list[i],',');
		Request request;
		request.type = request_split[0].substr(1);
		if(request.type.compare("add")){
			request.vmID = atoi(request_split[1].substr(1,request_split[1].length()-2).c_str());
			for(int j=0;j<VM_list.size();j++){
				if(VM_list[j].vmID==request.vmID){
					request.vmName = VM_list[j].vmName;
					break;
				}
			}
		}
		else{
			request.vmName = request_split[1].substr(1);
			request.vmID = atoi(request_split[2].substr(1,request_split[2].length()-2).c_str());
		}
		Requests.push_back(request);
	}
	return Requests;
}

void Input_Process(vector<Host> &Hosts,unordered_map<string, VM> &VMs, vector<vector<Request>> &Requests, vector<VMState> VM_list){

	int hostnum;
	scanf("%d",&hostnum);
	int i,j;
	char s[100];
	string temp;

	for(i=0;i<hostnum;i++){
		Host host;
		for(j=0;j<5;j++){
			scanf("%s",s);
			temp = s;
			switch(j){
				case 0:
					host.HostName = temp.substr(1,temp.size()-2);
					break;
				case 1:
					host.cpu = atoi(temp.c_str());
					break;
				case 2:
					host.mem = atoi(temp.c_str());
					break;
				case 3:
					host.price = atoi(temp.c_str());
					break;
				case 4:
					host.energy_cost = atoi(temp.c_str());
					break;
			}
		}
		host.performance_cost = host.cpu*host.mem*1.0/host.price;
		Hosts.push_back(host);
	}

	int vmnum;
	scanf("%d",&vmnum);

	for(i=0;i<vmnum;i++){
		VM vm;
		for(j=0;j<4;j++){
			scanf("%s",s);
			temp = s;
			switch(j){
				case 0:
					vm.vmName = temp.substr(1,temp.size()-2);
					break;
				case 1:
					vm.cpu = atoi(temp.c_str());
					break;
				case 2:
					vm.mem = atoi(temp.c_str());
					break;
				case 3:
					vm.node_flag = atoi(temp.c_str());
					break;
			}
		}
		VMs.insert(make_pair(vm.vmName, vm));
	}

	vector<Request> Request_day;
	int days;
	scanf("%d",&days);
	for(i=0;i<days;i++){
		int requestnum;
		scanf("%d",&requestnum);
		Request_day.clear();
		for(j=0;j<requestnum;j++){
			int k;
			Request request;
			for(k=0;k<3;k++){
				if(k==0){
					scanf("%s",s);
					temp = s;
					request.type = temp.substr(1,temp.size()-2);
				}
				else{
					if(request.type.compare("del")){
						if(k==1){
							scanf("%s",s);
							temp = s;
							request.vmName = temp.substr(0,temp.size()-1);
						}
						if(k==2){
							scanf("%s",s);
							temp = s;
							request.vmID = atoi(temp.c_str());
						}
					}
					else{
						if(k==2){
							scanf("%s",s);
							temp = s;
							request.vmID = atoi(temp.c_str());
							request.vmName = "empty";
						}
					}
				}
			}
			Request_day.push_back(request);
		}
		Requests.push_back(Request_day);
	}
}


vector<Host_purchase> Purchase(vector<Request> Requests, vector<HostState> &Host_list, unordered_map<string, VM> VMs, vector<Host> Hosts){
	vector<Host_purchase> purchase_result;
	purchase_result.clear();

	int cpu_request = 0;
	int mem_request = 0;

	for(int i=0;i<Requests.size();i++){

		if(!Requests[i].type.compare("add")){

			string name = Requests[i].vmName;

			cpu_request += VMs[name].cpu;
			mem_request += VMs[name].mem;
		}
	}

	int cpu_rest=0;
	int mem_rest=0;

	for(int i=0;i<Host_list.size();i++){
		cpu_rest += Host_list[i].cpu_A + Host_list[i].cpu_B;
		mem_rest += Host_list[i].mem_A + Host_list[i].mem_B;
	}


	int cpu_demand = 12*cpu_request - cpu_rest;
	int mem_demand = 12*mem_request - mem_rest;

	if(cpu_demand<0 && mem_demand<0){
	}
	else{
		int num1 = ceil(cpu_demand*1.0 / Hosts[0].cpu);
		int num2 = ceil(mem_demand*1.0 / Hosts[0].mem);
		int num = max(num1,num2);
		Host_purchase host_purchase;
		host_purchase.HostName = Hosts[0].HostName;
		host_purchase.Hostnum = num;
		purchase_result.push_back(host_purchase);
		for(int i=0;i<num;i++){
			HostState temp;

			temp.hostID = Host_list.size();
			temp.cpu_A = Hosts[0].cpu/2;
			temp.cpu_B = Hosts[0].cpu/2;
			temp.mem_A = Hosts[0].mem/2;
			temp.mem_B = Hosts[0].mem/2;
			temp.vm_num = 0;
			temp.flag = 0;
			temp.energy_cost = Hosts[0].energy_cost;
			Host_list.push_back(temp);
		}
	}
	cout << "(purchase, " << purchase_result.size() << ")" <<endl;
	if(purchase_result.size()>0){
		for(int i=0;i<purchase_result.size();i++){
			cout << "(";
			cout << purchase_result[i].HostName;
			cout << ", ";
			cout << purchase_result[i].Hostnum;
			cout << ")" << endl;
		}
	}
	return purchase_result;
}

void allocate(vector<Request> Requests, vector<HostState> &Host_list, vector<VMState> &VM_list, unordered_map<string, VM> VMs){

	for(int i=0;i<Requests.size();i++){
		string name = Requests[i].vmName;
		VM thevm = VMs[name];

		if(!Requests[i].type.compare("add")){
			int flag = 0;

			if(VMs[Requests[i].vmName].node_flag==0){

				for(int k=0;k<Host_list.size();k++){
					if((Host_list[k].cpu_A>=thevm.cpu)&&(Host_list[k].mem_A>=thevm.mem)){

						if(!((Host_list[k].cpu_B>=thevm.cpu)&&(Host_list[k].mem_B>=thevm.mem))){

							Host_list[k].cpu_A -= thevm.cpu;
							Host_list[k].mem_A -= thevm.mem;
							Host_list[k].vm_num += 1;

							VMState temp;
							temp.hostID = Host_list[k].hostID;
							temp.vmID = Requests[i].vmID;
							temp.vmName = Requests[i].vmName;
							temp.nodeFlag = 1;
							VM_list.push_back(temp);

							flag = 1;

							cout<< "(" << temp.hostID << ", A)" << endl;
							break;
						}

						else{
							if(Host_list[k].cpu_A>=Host_list[k].cpu_B){

								Host_list[k].cpu_A -= thevm.cpu;
								Host_list[k].mem_A -= thevm.mem;
								Host_list[k].vm_num += 1;

								VMState temp;
								temp.hostID = Host_list[k].hostID;
								temp.vmID = Requests[i].vmID;
								temp.vmName = Requests[i].vmName;
								temp.nodeFlag = 1;
								VM_list.push_back(temp);

								flag = 1;

								cout<< "(" << temp.hostID << ", A)" << endl;
								break;
							}
							else{

								Host_list[k].cpu_B -= thevm.cpu;
								Host_list[k].mem_B -= thevm.mem;
								Host_list[k].vm_num += 1;

								VMState temp;
								temp.hostID = Host_list[k].hostID;
								temp.vmID = Requests[i].vmID;
								temp.vmName = Requests[i].vmName;
								temp.nodeFlag = 2;
								VM_list.push_back(temp);

								flag = 1;
								cout << "(" << temp.hostID << ", B)" << endl;
								break;
							}
						}
					}
					else{

						if(((Host_list[k].cpu_B>=thevm.cpu)&&(Host_list[k].mem_B>=thevm.mem))){

							Host_list[k].cpu_B -= thevm.cpu;
							Host_list[k].mem_B -= thevm.mem;
							Host_list[k].vm_num += 1;

							VMState temp;
							temp.hostID = Host_list[k].hostID;
							temp.vmID = Requests[i].vmID;
							temp.vmName = Requests[i].vmName;
							temp.nodeFlag = 2;
							VM_list.push_back(temp);

							flag = 1;
							cout << "(" << temp.hostID << ", B)" << endl;
							break;
						}
					}

				}
			}

			else{

				for(int k=0;k<Host_list.size();k++){

					if(Host_list[k].cpu_A>=thevm.cpu/2 && Host_list[k].mem_A>=thevm.mem/2 && Host_list[k].cpu_B>=thevm.cpu/2 && Host_list[k].mem_B>=thevm.mem/2){

						Host_list[k].cpu_A -= thevm.cpu/2;
						Host_list[k].mem_A -= thevm.mem/2;
						Host_list[k].cpu_B -= thevm.cpu/2;
						Host_list[k].mem_B -= thevm.mem/2;
						Host_list[k].vm_num += 1;

						VMState temp;
						temp.hostID = Host_list[k].hostID;
						temp.vmID = Requests[i].vmID;
						temp.vmName = Requests[i].vmName;
						temp.nodeFlag = 0;
						VM_list.push_back(temp);

						flag = 1;
						cout << "(" <<temp.hostID <<")" << endl;
						break;
					}
				}
			}
			if(flag==0){
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
				cout<<"ERROR!!!!A Request Has Not Been Allocated!!!"<<endl;
			}

		}

		else{

			int k=0;
			for(k=0;k<VM_list.size();k++){

				if(VM_list[k].vmID==Requests[i].vmID){
					break;
				}
			}
			int hostid = VM_list[k].hostID;
			if(VM_list[k].nodeFlag==0){
				Host_list[hostid].cpu_A += thevm.cpu/2;
				Host_list[hostid].mem_A += thevm.mem/2;
				Host_list[hostid].cpu_B += thevm.cpu/2;
				Host_list[hostid].mem_B += thevm.mem/2;
				Host_list[hostid].vm_num -= 1;
			}
			else{
				if(VM_list[k].nodeFlag==1){
					Host_list[hostid].cpu_A += thevm.cpu/2;
					Host_list[hostid].mem_A += thevm.mem/2;
					Host_list[hostid].vm_num -= 1;
				}
				else{
					Host_list[hostid].cpu_B += thevm.cpu/2;
					Host_list[hostid].mem_B += thevm.mem/2;
					Host_list[hostid].vm_num -= 1;
				}
			}
			VM_list.erase(VM_list.begin()+k);
		}
	}
}


int main(){


	vector<Host> Hosts;
	unordered_map<string, VM> VMs;
	vector<VMState> VM_list;
	vector<HostState> Host_list;
	vector<vector<Request>> Requests;
	Input_Process(Hosts, VMs, Requests, VM_list);
	int i,j;
	for(i=0;i<Requests.size();i++){
		vector<Request> Day_request = Requests[i];
		vector<Host_purchase> purchase_result = Purchase(Day_request, Host_list, VMs, Hosts);
		int mignum = 0;
		cout << "(migration, " << mignum << ")" <<endl;
		allocate(Day_request, Host_list, VM_list, VMs);
	}
//	vector<string> input_data;
//	input_data = ReadInput();     //input_data:string���͵�vector��vector��ÿһ�����ļ��е�һ������(string����)
//	// �����������ݣ��õ���������Ϣ(�����Լ۱�����)���������Ϣ
//	vector<Host> Hosts;
//	unordered_map<string, VM> VMs;
//	Hosts = GetHosts(input_data); // ��ȡ�����������Լ۱ȵ����н��
//	VMs = GetVMs(input_data);     // ��ȡ�����������Ϣ
//	// ������������������ȡ�����󣬲����д���
//	int hostnum = atoi(input_data[0].c_str());
//	int vmnum = atoi(input_data[hostnum+1].c_str());
//	int days = atoi(input_data[hostnum+vmnum+2].c_str());       // ����������
//	int i;
//	// ��������������б���ʼ��
//	vector<HostState> Host_list;
//	vector<VMState> VM_list;
//	// ���δ���ÿ�������
//	int pos = hostnum + vmnum + 3;
//	int request_num = atoi(input_data[pos].c_str());
//	vector<string>::const_iterator first = input_data.begin()+pos+1;
//	vector<string>::const_iterator second = first + request_num;
//	for(i=0;i<days;i++){
//		// ȡ����i�����������
//		vector<string> request_list(first, second);
//		vector<Request> Requests = Request_process(request_list, VM_list);
//		// ���� + ����
//		vector<Host_purchase> purchase_result = Purchase(Requests, Host_list, VMs, Hosts);
//		// ������ز���
//		cout << "(migration, 0)" << endl;
//		allocate(Requests, Host_list, VM_list, VMs);
//		// ������ز���
//		pos = pos + request_num + 1;
//		request_num = atoi(input_data[pos].c_str());
//		first = second + 1;
//		second = first + request_num;
//	}


}
